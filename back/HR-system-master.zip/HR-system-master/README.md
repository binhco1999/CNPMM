# HR-system
# Project type: Maven 
# Language: Java Spring Boot (2.3.3) for BackEnd, Reactjs for Frontend
# Database: MS SQL Server 2017
