/*
insert into app_user(user_name,password,full_name) values('admin','123','Phan Đình Hoàng');
insert into app_user(user_name,password,full_name) values('webadmin','123','Tran Thi Bich Ngoc');

insert into department(department_name,start_date) values('Department 01','2019-01-18');
insert into department(department_name,start_date) values('Department 02','2018-02-18');
insert into department(department_name,start_date) values('Department 03','2020-06-18');
insert into department(department_name,start_date) values('Department 04','2018-11-18');
insert into department(department_name,start_date) values('Department 05','2019-01-18');
insert into department(department_name,start_date) values('Department 06','2018-02-18');
insert into department(department_name,start_date) values('Department 07','2020-06-18');
insert into department(department_name,start_date) values('Department 08','2018-11-18');

insert into position(position_name) values('Cong nhan');
insert into position(position_name) values('Nhan vien van phong');

insert into holiday(day_name,from_date,to_date,num_of_day_off,coefficient) values('Le 30/4','2020-04-30 00:01','2020-04-30 23:59',1,2)
insert into holiday(day_name,from_date,to_date,num_of_day_off,coefficient) values('Le 1/5','2020-05-01 00:01','2020-05-01 23:59',1,2)
insert into holiday(day_name,from_date,to_date,num_of_day_off,coefficient) values('Quoc Khanh Viet Nam','2020-09-02 00:01','2020-09-02 23:59',1,2)
*/