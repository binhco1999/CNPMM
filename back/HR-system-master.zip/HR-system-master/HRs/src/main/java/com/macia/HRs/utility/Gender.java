package com.macia.HRs.utility;

public enum Gender {
    MALE, FEMALE, UNDIFINED
}
